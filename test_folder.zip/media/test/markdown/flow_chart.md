![Figure](figures/flow_chart_figure_000.png)

![Figure](figures/flow_chart_figure_001.png)

![Figure](figures/flow_chart_figure_002.png)

国

2,420×1.36

